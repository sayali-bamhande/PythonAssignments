def printStar(num):
    pattern = " * "
    print(pattern * n)


if __name__ == '__main__':
    print("Enter the number : ")
    n = int(input())
    printStar(n)