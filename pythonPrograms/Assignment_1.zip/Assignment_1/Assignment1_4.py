def printWord():
    i = 0
    while i < 5:
        print("Marvellous")
        i += 1


if __name__ == '__main__':
    printWord()