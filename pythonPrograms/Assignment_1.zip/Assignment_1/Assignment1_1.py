def fun():
    print("Hello from Fun")


if __name__ == '__main__':
    print("Calling function fun()")
    fun()
