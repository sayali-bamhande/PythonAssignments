def printNum():
    print(*range(10, 0, -1))


if __name__ == '__main__':
    printNum()
