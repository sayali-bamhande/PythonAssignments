def findLength(name):
    return len(name)


if __name__ == '__main__':
    print("Enter the String : ")
    str1 = input()
    print(findLength(str1))
