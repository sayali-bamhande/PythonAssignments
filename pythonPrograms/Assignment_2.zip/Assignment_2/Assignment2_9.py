def getNumberLength(n):
    return len(n)


if __name__ == '__main__':
    print("Enter the number : ")
    n = input()
    print(getNumberLength(n))
